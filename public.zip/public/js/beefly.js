window.beefly = {
	// 公司
	company: '蜜蜂出行',
	// 系统
	platform: '客服管理平台',
	// 版本
	version: '1.0',
	// 皮肤
	skin: 'skin-red',

};
